# internet_folk_style

A modular style-system repo for early internet, meme, MySpace, dead-web, digital-folk-art, and screenshot-culture aesthetics.

This repo treats internet style as a **family of vernacular image systems** rather than one narrow nostalgia bucket. It organizes:
- old-web relics and 90s homepage chaos
- Y2K chrome, glass, plastic, and media-player futurism
- MySpace customization, glitter graphics, profile drama, and scene-coded self-decoration
- meme vernacular, image macros, screenshots, reaction-image logic, and anonymous repost culture
- glitch rot, compression damage, CRT bleed, 404 symbolism, and UI corruption
- digital folk art, thread archaeology, collective authorship, and remix-as-lineage
- vaporwave / mallsoft / corporate-afterlife branches that share strong overlap with dead-web internet imagery
- prompt modules, style merges, palette packs, negatives, and tag indexes for practical AI use

## Design stance

This repo is **not** trying to sanitize the web into tasteful retro branding.
It preserves the useful ugly parts:
- layout jank
- visible compression
- mismatched fonts
- browser clutter
- screenshot residue
- repost damage
- irony/sincerity collision
- collective authorship scars

## Best use cases

- image prompts
- video prompts
- scene/worldbuilding prompts
- UI shrine / desktop clutter prompts
- glitch collage systems
- internet-vernacular fashion/editorial prompts
- style merges with vaporwave, weirdcore, hyperpop, op art, emo scene, and corporate-decay systems

## Repo map

- `00_foundation/` theory + definitions
- `01_eras/` chronological web culture split
- `02_core_branches/` major style families
- `03_visual_elements/` visible components and interface language
- `04_materials_and_textures/` artifact logic and physical-feeling digital surfaces
- `05_motifs_and_objects/` concrete relics, symbols, and internet objects
- `06_composition_and_behavior/` how the style behaves, not just what it contains
- `07_palettes/` reusable color systems
- `08_prompt_modules/` modular prompt-writing parts
- `09_style_merges/` crossover recipes
- `10_reference_lists/` vocab hoards and tag dumps
- `99_appendix/` source framing, naming conventions, future expansion

## Recommended reading order

1. `STYLE_OVERVIEW.md`
2. `00_foundation/core_principles.md`
3. `01_eras/`
4. `02_core_branches/`
5. `08_prompt_modules/`
6. `10_reference_lists/prompt_tags_dump.md`

## Core thesis

Internet aesthetics work best when treated as:
- **digital folk art**
- **interface archaeology**
- **collective image rhetoric**
- **a living archive of repost damage**
